from parsermongo.mongo_writer import DBInserter

writer = DBInserter()

def register_file_name(name):
    label = name.split('-')[:-1] 
    label = '-'.join(label).upper() 
    writer.write_to_db('AMD_DATA', 'data_group', [{'name': label}]) 
    # writer.write_to_db('AMD_DATATRY', 'data_group', [{'name': label}])  
    #print(collection.find_one({'name': label}))

def register_new_lib_version(version):
    writer.write_to_db('AMD_DATA', 'rocm', [{'name': version.lower().strip('rocm')}])
    # writer.write_to_db('AMD_DATATRY', 'rocm', [{'name': version.lower().strip('rocm')}])

def register_new_spec_name(name):
    writer.write_to_db('AMD_DATA', 'platform', [{'name': name}]) 
    # writer.write_to_db('AMD_DATATRY', 'platform', [{'name': name}])

def write_data_to_mongo(file_name, list_of_dicts, file_path_object=None, database=None):
    if file_path_object:
        writer.write_to_db(file_path_object.parents[1].name, file_name, list_of_dicts)     #Replace with correct db name after resolving with team
    if database:
        writer.write_to_db(database, file_name, list_of_dicts)    

def write_spec_data_to_mongo():    #to be implemented
    pass      